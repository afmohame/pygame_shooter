import pygame as pg
from queue import PriorityQueue as pq
import convert_to_tiles as ctt
import world

class Find_path():
    def __init__(self):
        self.world = world.World()

    def walkable_neighbors(self, obj_position):
        neighbors_list = []
        neighbors = {
            "up": (obj_position[0], obj_position[y] + 1),
            "right": (obj_position[0] + 1, obj_position[y]),
            "down": (obj_position[0], obj_position[y] - 1),
            "left": (obj_position[0] - 1, obj_position[y])
        }

        for key, value in neighbors.items():
            x, y = value

            if 0 <= x < self.world.world_width - 1 and 0 <= y < self.world.world_height - 1:
                if self.world.world_map[y, x] in range(0, 2):
                    neighbors_list.append(value)

        return neighbors_list

    def find_it(self, obj_position, target_pos):
        start_tile = ctt.to_tiles(obj_position[0], obj_position[1])
        target_tile = ctt.to_tiles(target_pos[0], target_pos[1])
        checked = []
        open_set = pq()

        g = 0 #tile movement adds 1
        h = abs(start_tile[0] - target_tile[0]) + abs(start_tile[1] - target_tile[1])
        t = g + h
        parent = None

        open_set.put((t ,start_tile))
        next_check = self.walkable_neighbors(start_tile)

        for i in next_check:
            print(f"this is next_check {i}")
        
        """while open_set.empty():
            break"""


        
    